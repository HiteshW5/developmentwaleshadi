// Dummy Button component
export const Button = ({ children, ...props }) => <button {...props}>{children}</button>;