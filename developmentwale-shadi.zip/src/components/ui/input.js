// Dummy Input component
export const Input = (props) => <input {...props} />;